# 3.4-3.8-Interaction-Project

Using my designs I will attempt to recreate my two basic designs and eventually create a design based on the best aspects of each design.
